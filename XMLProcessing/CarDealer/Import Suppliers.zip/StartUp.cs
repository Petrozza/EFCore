﻿using CarDealer.Data;
using CarDealer.DTO.Input;
using CarDealer.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new CarDealerContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            var suppliersXml = File.ReadAllText(@"../../../Datasets/suppliers.xml"); //TODO
            System.Console.WriteLine(ImportSuppliers(context, suppliersXml));
        }


        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(SupplierInputModel[]), new XmlRootAttribute("Suppliers"));
            var textRead = new StringReader(inputXml);
            var suppliersDTOs = (SupplierInputModel[])xmlSerializer.Deserialize(textRead);

            List<Supplier> suppliers = new List<Supplier>();

            foreach (var supplierDTO in suppliersDTOs)
            {
                Supplier supplier = new Supplier()
                {
                    Name = supplierDTO.Name,
                    IsImporter = supplierDTO.IsImporter
                };
                suppliers.Add(supplier);
            }

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count()}";
        }
    }
}