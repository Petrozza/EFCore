﻿using CarDealer.Data;
using CarDealer.DTO.Input;
using CarDealer.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new CarDealerContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            var suppliersXml = File.ReadAllText("./Datasets/suppliers.xml"); 
            var partsXml = File.ReadAllText("./Datasets/parts.xml"); 
            var carsXml = File.ReadAllText("./Datasets/cars.xml"); 
            var customersXml = File.ReadAllText("./Datasets/customers.xml"); 
            System.Console.WriteLine(ImportSuppliers(context, suppliersXml));
            System.Console.WriteLine(ImportParts(context, partsXml));
            System.Console.WriteLine(ImportCars(context, carsXml));
            System.Console.WriteLine(ImportCustomers(context, customersXml));
        }

        public static string ImportCustomers(CarDealerContext context, string inputXml)
        {
            const string root = "Customers";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(CustomerInputModel[]), new XmlRootAttribute(root));
            var textRead = new StringReader(inputXml);
            var CustomersDtos = (CustomerInputModel[])xmlSerializer.Deserialize(textRead);

            List<Customer> customers = new List<Customer>();

            foreach (var custromerDto in CustomersDtos)
            {
                Customer customer = new Customer 
                {
                    Name = custromerDto.Name,
                    BirthDate = custromerDto.BirthDAte,
                    IsYoungDriver = custromerDto.IsYoungDriver
                };
                customers.Add(customer);
            }
            context.Customers.AddRange(customers);
            context.SaveChanges();
            return $"Successfully imported {customers.Count()}";
        }

        public static string ImportCars(CarDealerContext context, string inputXml)
        {
            const string root = "Cars";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(CarInputModel[]), new XmlRootAttribute(root));
            var textRead = new StringReader(inputXml);
            var carDtos = xmlSerializer.Deserialize(textRead) as CarInputModel[];

            var allParts = context.Parts.Select(x => x.Id).ToList();
            var cars = new List<Car>();

            foreach (var currentCar in carDtos)
            {
                var distinctedParts = currentCar.CarPartsInputModel.Select(x => x.Id).Distinct();
                var partCars = distinctedParts
                    .Intersect(allParts)
                    .Select(pc => new PartCar 
                    {
                        PartId = pc
                    })
                    .ToList();

                var car = new Car
                {
                    Make = currentCar.Make,
                    Model = currentCar.Model,
                    TravelledDistance = currentCar.TravelDistance,
                    PartCars = partCars
                };

                cars.Add(car);
            }
            context.Cars.AddRange(cars);
            context.SaveChanges();

            return $"Successfully imported {cars.Count}";
        }

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            const string root = "Parts";

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(PartInputModel[]), new XmlRootAttribute(root));

            var textRead = new StringReader(inputXml);

            var partInputModels = xmlSerializer.Deserialize(textRead) as PartInputModel[];

            var neededSuppliersIds = context.Suppliers
                .Select(x => x.Id)
                .ToList();

            var parts = partInputModels
                .Where(x => neededSuppliersIds.Contains(x.SupplierId))
                .Select(x => new Part
                {
                    Name = x.Name,
                    Price = x.Price,
                    Quantity = x.Quantity,
                    SupplierId = x.SupplierId
                })
                .ToList();

            context.Parts.AddRange(parts);
            context.SaveChanges();
               
            return $"Successfully imported {parts.Count}";
        }

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(SupplierInputModel[]), new XmlRootAttribute("Suppliers"));
            var textRead = new StringReader(inputXml);
            var suppliersDTOs = (SupplierInputModel[])xmlSerializer.Deserialize(textRead);

            List<Supplier> suppliers = new List<Supplier>();

            foreach (var supplierDTO in suppliersDTOs)
            {
                Supplier supplier = new Supplier()
                {
                    Name = supplierDTO.Name,
                    IsImporter = supplierDTO.IsImporter
                };
                suppliers.Add(supplier);
            }

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count()}";
        }
    }
}