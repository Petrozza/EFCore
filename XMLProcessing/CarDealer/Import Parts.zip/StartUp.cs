﻿using CarDealer.Data;
using CarDealer.DTO.Input;
using CarDealer.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new CarDealerContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            var suppliersXml = File.ReadAllText("./Datasets/suppliers.xml"); 
            var partsXml = File.ReadAllText("./Datasets/parts.xml"); 
            System.Console.WriteLine(ImportSuppliers(context, suppliersXml));
            System.Console.WriteLine(ImportParts(context, partsXml));
        }

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            const string root = "Parts";

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(PartInputModel[]), new XmlRootAttribute(root));

            var textRead = new StringReader(inputXml);

            var partInputModels = xmlSerializer.Deserialize(textRead) as PartInputModel[];

            var neededSuppliersIds = context.Suppliers
                .Select(x => x.Id)
                .ToList();

            var parts = partInputModels
                .Where(x => neededSuppliersIds.Contains(x.SupplierId))
                .Select(x => new Part
                {
                    Name = x.Name,
                    Price = x.Price,
                    Quantity = x.Quantity,
                    SupplierId = x.SupplierId
                })
                .ToList();

            context.Parts.AddRange(parts);
            context.SaveChanges();
               
            return $"Successfully imported {parts.Count}";
        }

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(SupplierInputModel[]), new XmlRootAttribute("Suppliers"));
            var textRead = new StringReader(inputXml);
            var suppliersDTOs = (SupplierInputModel[])xmlSerializer.Deserialize(textRead);

            List<Supplier> suppliers = new List<Supplier>();

            foreach (var supplierDTO in suppliersDTOs)
            {
                Supplier supplier = new Supplier()
                {
                    Name = supplierDTO.Name,
                    IsImporter = supplierDTO.IsImporter
                };
                suppliers.Add(supplier);
            }

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count()}";
        }
    }
}