﻿using System;


namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);

            var result = GetBooksByCategory(db, "horror mystery drama");
            Console.WriteLine(result);
        }

        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            var categoryList = input
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.ToLower())
                .ToArray();

            var allCategories = context.BooksCategories
                .Where(x => categoryList.Contains(x.Category.Name.ToLower()))
                .Select(x => x.Book.Title)
                .OrderBy(x => x)
                .ToList();

            var result = string.Join(Environment.NewLine, allCategories);
            return result;

        }

        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            var books = context.Books
                   .Where(x => x.ReleaseDate.Value.Year != year)
                   .Select(x =>  new 
                   {
                       x.BookId,
                       x.Title
                   } )
                   .OrderBy(x => x.BookId)
                   .ToList();

            var result = string.Join(Environment.NewLine, books.Select(x => x.Title));
            return result;
        }

        public static string GetBooksByPrice(BookShopContext context)
        {
            var books = context.Books
                .Where(x => x.Price > 40)
                .Select(x => new
                {
                    x.Title,
                    x.Price
                })
                .OrderByDescending(x => x.Price)
                .ToList();

            var sb = new StringBuilder();
            foreach (var book in books)
            {
                sb.AppendLine($"{book.Title} - ${book.Price:f2}");
            }
            return sb.ToString().TrimEnd();

           // var result = string.Join(Environment.NewLine, books.Select(x => $"{x.Title} - ${x.Price:f2}"));
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            //EditionType editionType = Enum.Parse<EditionType>("Gold");
            var books = context.Books
                .Where(x => x.EditionType == EditionType.Gold
                && x.Copies < 5000)
                .Select(x => new 
                {
                    x.BookId,
                    x.Title
                } )
                .OrderBy(x => x.BookId)
                .ToList();

            var result = string.Join(Environment.NewLine, books.Select(x => x.Title));
            return result;
        }


        public static string GetGoldenBooks(BookShopContext context, string command)
        {
            var agerestr = Enum.Parse<AgeRestriction>(command, true);
            var books = context.Books
                .Where(x => x.AgeRestriction == agerestr)
                .Select(x => x.Title)
                .OrderBy(x => x)
                .ToList();

            var result = string.Join(Environment.NewLine, books);
            return result;
        }
    }
    


}
