﻿using SoftUni.Data;
using SoftUni.Models;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SoftUniContext context = new SoftUniContext();
            Console.WriteLine(AddNewAddressToEmployee(context));
        }


        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            var address = new Address
            {
                AddressText = "Vitoshka 15",
                TownId = 4
            };
            context.Addresses.Add(address);
            context.SaveChanges();

            var employee = context.Employees
                          .FirstOrDefault(x => x.LastName == "Nakov");
            
            employee.AddressId = address.AddressId;
            context.SaveChanges();

            var addresses = context.Employees
                    .Select(x => new 
                {
                    x.Address.AddressText,
                    x.Address.AddressId
                })
                    .OrderByDescending(x => x.AddressId)
                    .Take(10)
                    .ToList();

            var sb = new StringBuilder();
            foreach (var pich in addresses)
            {
                sb.AppendLine(pich.AddressText);
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            var employees = context.Employees
                            .Where(x => x.Department.Name == "Research and Development")
                            .OrderBy(x => x.Salary)
                            .ThenByDescending(x => x.FirstName)
                            .Select(x => new
                            {
                                x.FirstName,
                                x.LastName,
                                x.Department.Name,
                                x.Salary,

                            });

            var sb = new StringBuilder();
            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} from {employee.Name} - ${employee.Salary:f2}");
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var employees = context.Employees
                            .Where(x => x.Salary > 50000)
                            .Select(x => new
                            {
                                x.FirstName,
                                x.Salary
                            })
                            .OrderBy(x => x.FirstName);

            var sb = new StringBuilder();
            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} - {employee.Salary:f2}");
            }

            return sb.ToString().TrimEnd();
        }
        
        
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            var employees = context.Employees
                .OrderBy(x => x.EmployeeId)
                .Select(x => new
                {
                    x.FirstName,
                    x.LastName,
                    x.MiddleName,
                    x.JobTitle,
                    x.Salary
                });

            var sb = new StringBuilder();
            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} {employee.MiddleName} {employee.JobTitle} {employee.Salary:f2}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
