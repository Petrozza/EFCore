﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SoftUniContext context = new SoftUniContext();
            Console.WriteLine(RemoveTown(context));
            
        }

        public static string RemoveTown(SoftUniContext context)
        {
            var townToDelete= context.Towns
                .Include(x => x.Addresses)
                .FirstOrDefault(x => x.Name == "Seattle");

            var allAddressIds = townToDelete.Addresses.Select(x => x.AddressId).ToList();

            var employees = context.Employees
                .Where(x => x.AddressId.HasValue && allAddressIds.Contains(x.AddressId.Value))
                .ToList();

            foreach (var emp in employees)
            {
                emp.AddressId = null;
            }

            foreach (var addressId in allAddressIds)
            {
                var address = context.Addresses
                    .Where(x => x.AddressId == addressId)
                    .Single();

                context.Addresses.Remove(address);
            }

            context.Towns.Remove(townToDelete);

            context.SaveChanges();

            var result = $"{allAddressIds.Count} addresses in Seattle were deleted";

            return result;
        }

        public static string DeleteProjectById(SoftUniContext context) 
        {
            var emplprojectsToDelete = context.EmployeesProjects
                .Where(x => x.ProjectId == 2);

            var projectToDelete = context.Projects
               .FirstOrDefault(x => x.ProjectId == 2);

            foreach (var ep in emplprojectsToDelete)
            {
                context.EmployeesProjects.Remove(ep);
            }

            context.Projects.Remove(projectToDelete);

            context.SaveChanges();

            var printables = context.Projects
                .Select(x => x.Name)
                .Take(10)
                .ToList();

            var sb = new StringBuilder();
            foreach (var pr in printables)
            {
                sb.AppendLine(pr);
            }

            return sb.ToString().TrimEnd();
        }


        public static string GetEmployeesByFirstNameStartingWithSa(SoftUniContext context)
        {
            var employees = context.Employees
                .Where(x => x.FirstName.StartsWith("Sa"))
                .Select(x => new
                {
                    x.FirstName,
                    x.LastName,
                    x.JobTitle,
                    x.Salary
                })
                .OrderBy(x => x.FirstName)
                .ThenBy(x => x.LastName)
                .ToList();
            var sb = new StringBuilder();
            foreach (var emp in employees)
            {
                sb.AppendLine($"{emp.FirstName} {emp.LastName} - {emp.JobTitle} - (${emp.Salary:f2})");
            }
            return sb.ToString().TrimEnd();
        }

        public static string IncreaseSalaries(SoftUniContext context)
        {
            var choosenDepartments = new string[]
            {
                "Engineering",
                "Tool Design",
                "Marketing",
                "Information Services"
            };

            var neededEmployees = context.Employees
                .Where(x => choosenDepartments.Contains(x.Department.Name))
                .OrderBy(x => x.FirstName)
                .ThenBy(x => x.LastName)
                .ToList();

            foreach (var emp in neededEmployees)
            {
                emp.Salary *= 1.12m;
            }

            context.SaveChanges();

            var sb = new StringBuilder();
            foreach (var emp in neededEmployees)
            {
                sb.AppendLine($"{emp.FirstName} {emp.LastName} (${emp.Salary:f2})");
            }
            return sb.ToString().TrimEnd();
        }
    }
}
