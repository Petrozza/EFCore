﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new CarDealerContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            var suppliersJson = File.ReadAllText("../../../Datasets/suppliers.json");
            var partsJson = File.ReadAllText("../../../Datasets/parts.json");
            var carsJson = File.ReadAllText("../../../Datasets/cars.json");

            ImportSuppliers(context, suppliersJson);
            ImportParts(context, partsJson);
            Console.WriteLine(ImportCars(context, carsJson));
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var suppliersDtos = JsonConvert.DeserializeObject<Supplier[]>(inputJson);

            //List<Supplier> suppliers = suppliersDtos.Select(x => new Supplier
            //{
            //    Name = x.Name,
            //    IsImporter = x.IsImporter
            //})
            //    .ToList();

            context.Suppliers.AddRange(suppliersDtos);
            context.SaveChanges();
             return $"Successfully imported {suppliersDtos.Count()}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var suppliedIds = context.Suppliers
                .Select(x => x.Id)
                .ToArray();

            var parts = JsonConvert
                .DeserializeObject<Part[]>(inputJson)
                .Where(s => suppliedIds.Contains(s.SupplierId))
                .ToArray();
            

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count()}.";
        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            var carsToImport = JsonConvert.DeserializeObject<CarInputModel[]>(inputJson);
            
            List<Car> ListOfCars = new List<Car>();

            foreach (var car in carsToImport)
            {
                var currentCar = new Car
                {
                    Make = car.Make,
                    Model = car.Model,
                    TravelledDistance = car.TravelledDistance
                };

                foreach (var partId in car?.PartsId.Distinct())
                {
                    currentCar.PartCars.Add(new PartCar
                    {
                        PartId = partId
                    });
                }
                ListOfCars.Add(currentCar);
                   

            }


            context.Cars.AddRange(ListOfCars);
            context.SaveChanges();

            return $"Successfully imported {ListOfCars.Count()}.";

        }
    }
}