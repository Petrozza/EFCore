﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new CarDealerContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            var suppliersJson = File.ReadAllText("../../../Datasets/suppliers.json");
            var partsJson = File.ReadAllText("../../../Datasets/parts.json");
            
            ImportSuppliers(context, suppliersJson);
            Console.WriteLine(ImportParts(context, partsJson));
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var suppliersDtos = JsonConvert.DeserializeObject<Supplier[]>(inputJson);

            //List<Supplier> suppliers = suppliersDtos.Select(x => new Supplier
            //{
            //    Name = x.Name,
            //    IsImporter = x.IsImporter
            //})
            //    .ToList();

            context.Suppliers.AddRange(suppliersDtos);
            context.SaveChanges();
             return $"Successfully imported {suppliersDtos.Count()}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var suppliedIds = context.Suppliers
                .Select(x => x.Id)
                .ToArray();

            var parts = JsonConvert
                .DeserializeObject<Part[]>(inputJson)
                .Where(s => suppliedIds.Contains(s.SupplierId))
                .ToArray();
            

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count()}.";
        }
    }
}