﻿namespace Cinema.DataProcessor
{
    using System;

    using Data;

    public class Serializer
    {
        public static string ExportTopMovies(CinemaContext context, int rating)
        {
            return "NOT YET";
        }

        public static string ExportTopCustomers(CinemaContext context, int age)
        {
            return "NOT YET";
        }
    }
}