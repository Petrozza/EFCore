﻿namespace Cinema.DataProcessor
{
    using System;
    using System.Linq;
    using Cinema.Data.Models;
    using Data;
    using Newtonsoft.Json;

    public class Serializer
    {
        public static string ExportTopMovies(CinemaContext context, int rating)
        {
            var movies = context.Movies
                .ToArray()
                .Where(r => r.Rating >= rating && r.Projections.Any(s => s.Tickets.Count > 0))
                .Select(x => new
                {
                    MovieName = x.Title,
                    Rating = x.Rating.ToString("f2"),
                    TotalIncomes = x.Projections.SelectMany(p => p.Tickets).Sum(w => w.Price),
                    Customers = x.Projections.SelectMany(x => x.Tickets.Select(c => new  
                    {
                        FirstName = c.Customer.FirstName,
                        LastName = c.Customer.LastName,
                        Balance = c.Customer.Balance.ToString("f2")
                    }))
                    .OrderByDescending(x => x.Balance.ToString())
                    .ThenBy(x => x.FirstName)
                    .ToArray()
                })
                .OrderByDescending(x => x.Rating)
                .ThenByDescending(x => x.TotalIncomes)
                .Take(10)
                .ToArray();

            return JsonConvert.SerializeObject(movies, Formatting.Indented);
        }

        public static string ExportTopCustomers(CinemaContext context, int age)
        {
            return "NOT YET";
        }
    }
}