﻿using Microsoft.Data.SqlClient;
using System;
using System.Data;

namespace ConsoleApp39
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = "Server=.; Database = MinionsDB; Integrated Security=True";

            using SqlConnection connection = new SqlConnection(connectionString);

            connection.Open();

            int id = int.Parse(Console.ReadLine());

            string selectionCommandString = @"SELECT Name FROM Villains WHERE Id = @Id";

            using SqlCommand command = new SqlCommand(selectionCommandString, connection);
            command.Parameters.AddWithValue("@Id", id);
            var result = command.ExecuteScalar();

            string missingMinionsQuery = @"SELECT ROW_NUMBER() OVER (ORDER BY m.Name) as RowNum,
                                         m.Name, 
                                         m.Age
                                         FROM MinionsVillains AS mv
                                         JOIN Minions As m ON mv.MinionId = m.Id
                                         WHERE mv.VillainId = @Id
                                         ORDER BY m.Name ";

            if (result == null)
            {
                Console.WriteLine($"No villain with ID {id} exists in the database.");
            }
            else
            {
                Console.WriteLine($"Villain: {result}");
                using (var minionCommand = new SqlCommand(missingMinionsQuery, connection))
                {
                    minionCommand.Parameters.AddWithValue("@Id", id);
                    using (var reader = minionCommand.ExecuteReader())
                    {
                        if (!reader.HasRows)
                        {
                            Console.WriteLine("(no minions)");
                        }
                        while (reader.Read())
                        {
                            Console.WriteLine($"{reader[0]}.ToString {reader[1]} {reader[2]}");
                        }
                    }
                }

            }

            //using (reader) 
            //{
            //    while (reader.Read())
            //    {
            //        string VName = (string)reader["Name"];
            //        int Count = (int)reader["MinionsCount"];
            //        Console.WriteLine($"{VName}-{Count}");
            //    }

            //}

        }
    }
}
